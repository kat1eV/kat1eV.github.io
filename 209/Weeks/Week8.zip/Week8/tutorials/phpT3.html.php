<?php ?>

<!--Katherine Vogt
    CSC209
    PHP Tutorials
    Tutorial: Data Types
-->

<html>

</html>